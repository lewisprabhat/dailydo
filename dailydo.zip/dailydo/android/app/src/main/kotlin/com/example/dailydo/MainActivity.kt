package com.example.dailydo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
